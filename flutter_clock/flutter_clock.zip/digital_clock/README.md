# Digital Clock [![Actions Status](https://github.com/Hecatoncheir/flutter_clock/workflows/check/badge.svg)](https://github.com/Hecatoncheir/flutter_clock/actions)

It has a light theme and a dark theme.

<img src='digital.gif' width='350'>

<img src='digital_dark.png' width='350'>

<img src='digital_light.png' width='350'>
