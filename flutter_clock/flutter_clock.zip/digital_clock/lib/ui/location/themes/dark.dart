import 'dart:ui';

import 'package:flutter/material.dart';

class Dark {
  const Dark();

  static Color foreground = Color(0xFFBB4E7F);
  static Shadow shadow =
      Shadow(color: Color(0xFF422753), offset: Offset(0, -1));
}
