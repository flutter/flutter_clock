import 'package:flutter_driver/driver_extension.dart';
import 'package:digital_clock/main.dart' as application;

void main() {
  enableFlutterDriverExtension();
  application.main();
}
